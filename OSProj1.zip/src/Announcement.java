/**
 * This class stores public IP address and port number of the MAPPER.
 */
public class Announcement {
	public static final String MAPPER_IP = "localhost";
	public static final int MAPPER_PORT = 1111;
}
